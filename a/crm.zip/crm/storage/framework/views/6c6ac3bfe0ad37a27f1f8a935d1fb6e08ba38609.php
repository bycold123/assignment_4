<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
    <title><?php echo e(config('app.name', 'CRM pro')); ?></title>

    <!-- Scripts -->
    <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <!-- <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
    <!-- Styles -->
    <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/morris/morris.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body class="deshboard-1">

                        <?php if(auth()->guard()->guest()): ?>
                            <?php echo $__env->yieldContent('content'); ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </li>
                            <div class="main-wrapper">
                                <div class="header">
                                    <div class="header-left">
                                        <a href="index.html" class="logo">
                                            <img src="assets/img/logo.png" width="40" height="40" alt="">
                                        </a>
                                    </div>
                                    <div class="page-title-box pull-left">
                                        <h3>CRM Pro</h3>
                                    </div>
                                    <a id="mobile_btn" class="mobile_btn pull-left" href="#sidebar"><i class="fa fa-bars"
                                            aria-hidden="true"></i></a>
                                    <ul class="nav navbar-nav navbar-right user-menu pull-right">
                                        <li class="dropdown hidden-xs">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o"></i> <span
                                                    class="badge bg-purple pull-right">3</span></a>
                                            <div class="dropdown-menu notifications">
                                             
                                             
                                                
                                            </div>
                                        </li>
                                        <li class="dropdown hidden-xs">
                                            <a href="javascript:;" id="open_msg_box" class="hasnotifications"><i class="fa fa-comment-o"></i>
                                                <span class="badge bg-purple pull-right">8</span></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="profile.html" class="dropdown-toggle user-link" data-toggle="dropdown" title="Admin">
                                                <span class="user-img"><img class="img-circle" src="assets/img/user.jpg" width="40" alt="Admin">
                                                    <span class="status online"></span></span>
                                                <span>Admin</span>
                                                <i class="caret"></i>
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li><a href="profile.html">My Profile</a></li>
                                                <li><a href="edit-profile.html">Edit Profile</a></li>
                                                <li><a href="settings.html">Settings</a></li>
                                                <li>
                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                    <?php echo e(__('Logout')); ?>

                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <div class="dropdown mobile-user-menu pull-right">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i
                                                class="fa fa-ellipsis-v"></i></a>
                                        <ul class="dropdown-menu pull-right">
                                            <li><a href="profile.html">My Profile</a></li>
                                            <li><a href="edit-profile.html">Edit Profile</a></li>
                                            <li><a href="settings.html">Settings</a></li>
                                            <li>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                    <?php echo e(__('Logout')); ?>

                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sidebar" id="sidebar">
                                    <div class="sidebar-inner slimscroll">
                                        <div id="sidebar-menu" class="sidebar-menu">
                                            <ul>
                                                <li class="active">
                                                    <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                                </li>
                                                
                                                <li>
                                                    <a href="<?php echo e(route('client')); ?>">Clients</a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('employee')); ?>">Employees</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                            <div class="sidebar-overlay" data-reff="#sidebar"></div>

                        <?php endif; ?>



    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
    <!-- <script type="text/javascript" src="<?php echo e(asset('assets/plugins/morris/morris.min.js')); ?>"></script> -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/raphael/raphael-min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/app.js')); ?>"></script>		


</body>
</html>
<?php /**PATH C:\xampp\htdocs\test\www\comp1230\assigment4\crm\resources\views/layouts/app.blade.php ENDPATH**/ ?>